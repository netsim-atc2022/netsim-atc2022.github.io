#define _POSIX_C_SOURCE 200809L

#include <fcntl.h>
#include <mqueue.h>
#include <sched.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory>
#include <string>
#include <vector>

enum class Method { kUndefined, kSocket, kSem, kSpin, kMsgQueue };
static Method METHOD_ = Method::kUndefined;

static int PARENT_CPU_ = -1;
static int CHILD_CPU_ = -1;

enum { MAX_CPU_NUM = 56 };

static void complain_and_quit_(const char *what) {
    assert(what);
    std::perror(what);
    std::exit(-1);
}

static void pin_to_cpu_(int cpu_num) {
    cpu_set_t *cpu_set = NULL;
    bool set_affinity_suceeded = false;

    cpu_set = CPU_ALLOC(MAX_CPU_NUM);

    if (cpu_set) {  // Good, the CPU set allocation succeeded

        size_t cpu_set_size = CPU_ALLOC_SIZE(MAX_CPU_NUM);

        // Clear the CPU set
        CPU_ZERO_S(cpu_set_size, cpu_set);
        // And then add the new_cpu_num as the only element of the set
        CPU_SET_S(cpu_num, cpu_set_size, cpu_set);

        int rc = sched_setaffinity(0, cpu_set_size, cpu_set);

        set_affinity_suceeded = (rc == 0);
    }

    if (!set_affinity_suceeded) {
        std::perror("sched_setaffinity");
        std::abort();
    }

    if (cpu_set) {
        CPU_FREE(cpu_set);
    }
}

template <typename Itr>
static double kahan_sum(Itr cbegin, Itr cend) {
    double sum = 0.0;
    double c = 0.0;

    auto itr = cbegin;
    while (itr != cend) {
        const double num = *itr;
        double y = num - c;
        double t = sum + y;
        c = (t - sum) - y;
        sum = t;
        ++itr;
    }

    return sum;
}

class SwitchIface {
   public:
    virtual void init_parent() {}
    virtual void init_child() {}

    virtual void switch_to_child() = 0;
    virtual void switch_to_parent() = 0;
    virtual void wait_for_child() = 0;
    virtual void wait_for_parent() = 0;
};

class SocketSwitch : public SwitchIface {
   public:
    SocketSwitch() : child_sockfd_{0}, parent_sockfd_{0} {
        std::printf("Using UNIX domain socket switch.\n");

        int sock_fds[2]{0, 0};
        auto socketpair_retv = socketpair(AF_UNIX, SOCK_SEQPACKET, 0, sock_fds);

        if (socketpair_retv != 0) {
            complain_and_quit_("socketpair");
        }

        child_sockfd_ = sock_fds[0];
        parent_sockfd_ = sock_fds[1];
    }

    virtual void switch_to_child() override { send_(parent_sockfd_); }

    virtual void switch_to_parent() override { send_(child_sockfd_); }

    virtual void wait_for_child() override { recv_(parent_sockfd_); }

    virtual void wait_for_parent() override { recv_(child_sockfd_); }

   private:
    void send_(int sockfd) {
        send_buf_ = true;
        auto send_rc = send(sockfd, &send_buf_, sizeof(send_buf_), 0);
        if (send_rc != sizeof(send_buf_)) {
            complain_and_quit_("send");
        }
    }

    void recv_(int sockfd) {
        recv_buf_ = false;
        auto recv_rc = recv(sockfd, &recv_buf_, sizeof(recv_buf_), 0);
        if (recv_rc != sizeof(recv_buf_)) {
            complain_and_quit_("recv");
        }
        assert(recv_buf_ == true);
    }

    int child_sockfd_, parent_sockfd_;
    bool send_buf_, recv_buf_;
};

class SemSwitch : public SwitchIface {
   public:
    SemSwitch() {
        enum {
            kSMemNBytes = 4096,
        };

        std::printf("Using semaphore switch.\n");

        void *psmem = mmap(nullptr, kSMemNBytes, PROT_READ | PROT_WRITE,
                           MAP_SHARED | MAP_ANONYMOUS, -1, 0);

        if (!psmem) {
            complain_and_quit_("mmap");
        }

        std::memset(psmem, 0, kSMemNBytes);

        shared_ = static_cast<Shared *>(psmem);

        sem_init(&shared_->parent_sem, 1, 0);
        sem_init(&shared_->child_sem, 1, 0);
    }

    virtual void switch_to_child() override { post_(&shared_->parent_sem); }

    virtual void switch_to_parent() override { post_(&shared_->child_sem); }

    virtual void wait_for_child() override { wait_(&shared_->child_sem); }

    virtual void wait_for_parent() override { wait_(&shared_->parent_sem); }

   private:
    static void post_(sem_t *sem) {
        int sem_post_retv = sem_post(sem);
        if (sem_post_retv == -1) {
            complain_and_quit_("sem_post");
        }
    }

    static void wait_(sem_t *sem) {
        int sem_wait_retv = sem_wait(sem);
        if (sem_wait_retv == -1) {
            complain_and_quit_("sem_wait");
        }
    }

    struct Shared {
        sem_t parent_sem, child_sem;
    } * shared_{nullptr};
};

class SpinSwitch : public SwitchIface {
   public:
    SpinSwitch() {
        enum {
            kSMemNBytes = 4096,
        };

        std::printf("Using spin+yield switch.\n");

        void *psmem = mmap(nullptr, kSMemNBytes, PROT_READ | PROT_WRITE,
                           MAP_SHARED | MAP_ANONYMOUS, -1, 0);

        if (!psmem) {
            complain_and_quit_("mmap");
        }

        std::memset(psmem, 0, kSMemNBytes);

        pparent_ = new (psmem) std::atomic<bool>(false);
        pchild_ = new (static_cast<char *>(psmem) + sizeof(std::atomic<bool>))
            std::atomic<bool>(false);
    }

    virtual void switch_to_child() override { signal_(pparent_); }

    virtual void switch_to_parent() override { signal_(pchild_); }

    virtual void wait_for_child() override { wait_(pchild_); }

    virtual void wait_for_parent() override { wait_(pparent_); }

   private:
    void signal_(std::atomic<bool> *pb) {
        pb->store(true, std::memory_order_release);
    }

    void wait_(std::atomic<bool> *pb) {
        while (true) {
            bool was_available = pb->load(std::memory_order_relaxed);
            if (was_available &&
                pb->compare_exchange_weak(was_available, false,
                                          std::memory_order_acquire)) {
                break;
            }
            sched_yield();
        }
    }

    std::atomic<bool> *pparent_{nullptr}, *pchild_{nullptr};
};

class MsgQueueSwitch : public SwitchIface {
   public:
    MsgQueueSwitch() {
        std::printf("Using POSIX message queue switch.\n");

        name_suffix_ = std::to_string(static_cast<int>(std::time(nullptr)));

        cleanup_fns().push_back(std::bind(&MsgQueueSwitch::unlink_, this));

        std::atexit(&MsgQueueSwitch::cleanup_);
        std::at_quick_exit(&MsgQueueSwitch::cleanup_);
    }

    void init_parent() override {
        parent_queue_ =
            init_mq_(parent_mq_name().c_str(), O_WRONLY | O_CREAT | O_EXCL);
        child_queue_ =
            init_mq_(child_mq_name().c_str(), O_RDONLY | O_CREAT | O_EXCL);
    }

    void init_child() override {
        parent_queue_ = spinwait_init_mq_(parent_mq_name().c_str(), O_RDONLY);
        child_queue_ = spinwait_init_mq_(child_mq_name().c_str(), O_WRONLY);
    }

    virtual void switch_to_child() override {
        mq_send(parent_queue_, MSG, 0, 0);
    }

    virtual void switch_to_parent() override {
        mq_send(child_queue_, MSG, 0, 0);
    }

    virtual void wait_for_child() override { recv_(child_queue_); }

    virtual void wait_for_parent() override { recv_(parent_queue_); }

   private:
    static constexpr const char *PARENT_MQ_NAME_PREFIX =
        "/mq_parent_context_switch";
    static constexpr const char *CHILD_MQ_NAME_PREFIX =
        "/mq_child_context_switch";
    static constexpr const char *MSG = "\0";

    static std::vector<std::function<void()>> &cleanup_fns() {
        static std::vector<std::function<void()>> retval;
        return retval;
    }

    static mqd_t init_mq_(const char *name, int flags) {
        struct mq_attr mattr = {0};
        mattr.mq_flags = 0;
        mattr.mq_maxmsg = 4;
        mattr.mq_msgsize = 256;
        mattr.mq_curmsgs = 0;

        mqd_t retval = mq_open(name, flags, 0666, &mattr);

        if (retval == static_cast<mqd_t>(-1)) {
            complain_and_quit_("mq_open");
        }

        return retval;
    }

    const std::string parent_mq_name() const {
        return (PARENT_MQ_NAME_PREFIX + name_suffix_);
    }

    const std::string child_mq_name() const {
        return (CHILD_MQ_NAME_PREFIX + name_suffix_);
    }

    static mqd_t spinwait_init_mq_(const char *name, int flags) {
        auto retval = mq_open(name, flags);

        while (retval == static_cast<mqd_t>(-1)) {
            usleep(1000);
            retval = mq_open(name, flags);
        }

        return retval;
    }

    static void recv_(mqd_t queue) {
        enum { BUF_NBYTES = 256 };
        char buf_[BUF_NBYTES] = {0};
        mq_receive(queue, &(buf_[0]), BUF_NBYTES, nullptr);
    }

    static void cleanup_() {
        for (auto &cleanup_fn : cleanup_fns()) {
            cleanup_fn();
        }
    }

    void unlink_() {
        mq_unlink(parent_mq_name().c_str());
        mq_unlink(child_mq_name().c_str());
    }

    mqd_t parent_queue_, child_queue_;
    std::string name_suffix_;
};

static std::unique_ptr<SwitchIface> SWITCH{nullptr};

enum { kNWarmupItrs = 10000, kNMeasurements = 100000 };
static std::array<double, kNMeasurements> MEASUREMENTS_;

static void child_procedure_() {
    assert(SWITCH);

    pin_to_cpu_(CHILD_CPU_);
    std::printf("Child pinned to CPU %d\n", CHILD_CPU_);

    SWITCH->init_child();

    for (std::size_t idx = 0; idx < kNWarmupItrs; ++idx) {
        SWITCH->wait_for_parent();
        SWITCH->switch_to_parent();
    }

    for (std::size_t idx = 0; idx < kNMeasurements; ++idx) {
        SWITCH->wait_for_parent();
        SWITCH->switch_to_parent();
    }

    std::exit(EXIT_SUCCESS);
}

static void parent_procedure_() {
    assert(SWITCH);

    pin_to_cpu_(PARENT_CPU_);
    std::printf("Parent pinned to CPU %d\n", PARENT_CPU_);

    SWITCH->init_parent();

    for (std::size_t idx = 0; idx < kNWarmupItrs; ++idx) {
        SWITCH->switch_to_child();
        SWITCH->wait_for_child();
    }

    for (std::size_t idx = 0; idx < kNMeasurements; ++idx) {
        auto t0 = std::chrono::high_resolution_clock::now();
        SWITCH->switch_to_child();
        SWITCH->wait_for_child();
        auto t1 = std::chrono::high_resolution_clock::now();

        auto delta_t =
            std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0)
                .count();

        MEASUREMENTS_[idx] = delta_t;
    }

    SWITCH->switch_to_child();
}

static void init_switch_() {
    assert(METHOD_ != Method::kUndefined);

    switch (METHOD_) {
        case Method::kSocket:
            SWITCH.reset(new SocketSwitch{});
            break;
        case Method::kSem:
            SWITCH.reset(new SemSwitch{});
            break;
        case Method::kSpin:
            SWITCH.reset(new SpinSwitch{});
            break;
        case Method::kMsgQueue:
            SWITCH.reset(new MsgQueueSwitch{});
            break;
        default:
            abort();
            break;
    }
}

static void parse_args_(int argc, char **argv) {
    assert(argv);

    static const char *usage_fmt = "Usage: %s socket|sem|spin|msgqueue\n";
    bool bad_parse = false;

    if (argc != 4) {
        bad_parse = true;
        goto parse_args_quit;
    }

    if (std::strcmp(argv[1], "socket") == 0) {
        METHOD_ = Method::kSocket;
    } else if (std::strcmp(argv[1], "sem") == 0) {
        METHOD_ = Method::kSem;
    } else if (std::strcmp(argv[1], "spin") == 0) {
        METHOD_ = Method::kSpin;
    } else if (std::strcmp(argv[1], "msgqueue") == 0) {
        METHOD_ = Method::kMsgQueue;
    } else {
        bad_parse = true;
    }

    PARENT_CPU_ = std::stoi(argv[2]);
    CHILD_CPU_ = std::stoi(argv[3]);

    if (PARENT_CPU_ == -1 || CHILD_CPU_ == -1) {
        bad_parse = true;
    }

parse_args_quit:
    if (bad_parse) {
        std::printf(usage_fmt, argv[0]);
        complain_and_quit_("bad command line arguments");
    }
}

int main(int argc, char **argv) {
    parse_args_(argc, argv);
    init_switch_();

    const auto child_pid = fork();

    switch (child_pid) {
        case -1:
            complain_and_quit_("fork");
            break;
        case 0:  // child
            child_procedure_();
            break;
        default:  // parent
            parent_procedure_();
            break;
    }

    int wstatus = 0;
    auto waitpid_retv = waitpid(child_pid, &wstatus, 0);
    if (waitpid_retv != child_pid) {
        complain_and_quit_("waitpid");
    }

    if (!WIFEXITED(wstatus) || WEXITSTATUS(wstatus) != 0) {
        complain_and_quit_("child exited abnormally");
    }

    // *Compute Statistics*
    // Mean

    const auto sum = kahan_sum(MEASUREMENTS_.cbegin(), MEASUREMENTS_.cend());
    const auto mean = sum / static_cast<double>(MEASUREMENTS_.size());

    // Standard deviation
    std::array<double, kNMeasurements> squared_diffs;
    for (std::size_t idx = 0; idx < squared_diffs.size(); ++idx) {
        squared_diffs[idx] = std::pow(MEASUREMENTS_[idx] - mean, 2);
    }
    auto sample_stddev =
        std::sqrt(kahan_sum(squared_diffs.cbegin(), squared_diffs.cend()) /
                  static_cast<double>(squared_diffs.size() - 1));

    // Print the results

    std::printf("Arithmetic mean context-switch roundtrip:\t%f ns\n", mean);
    std::printf("Sample std. dev. context-switch roundtrip:\t%f ns\n",
                sample_stddev);
    std::printf(
        "Min. context-switch roundtrip:\t%f ns\n",
        *std::min_element(MEASUREMENTS_.cbegin(), MEASUREMENTS_.cend()));
    std::printf(
        "Max. context-switch roundtrip:\t%f ns\n",
        *std::max_element(MEASUREMENTS_.cbegin(), MEASUREMENTS_.cend()));

    return 0;
}
