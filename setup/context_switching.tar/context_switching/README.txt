This benchmark measures the performance of process context switching when
invoked by different mechanisms (sockets, semaphores, etc.).

To benchmark context switching driven by UNIX sockets:

```
$ make socket_measurement
```

To benchmark context switching driven by semaphores:

```
$ make sem_measurement
```

Measurements
********************************************************************************

* Socket benchmark run on koios6 

perf stat taskset 0x01 ./context_switching socket
Using socket switch.
Arithmetic mean context-switch roundtrip:	6.051500 microseconds
Sample std. dev. context-switch roundtrip:	1.761028 microseconds
Min. context-switch roundtrip:	6.000000 microseconds
Max. context-switch roundtrip:	307.000000 microseconds

 Performance counter stats for 'taskset 0x01 ./context_switching socket':

            761.51 msec task-clock:u              #    0.996 CPUs utilized
                 0      context-switches:u        #    0.000 K/sec
                 0      cpu-migrations:u          #    0.000 K/sec
               609      page-faults:u             #    0.800 K/sec
        81,572,151      cycles:u                  #    0.107 GHz
        25,686,230      instructions:u            #    0.31  insn per cycle
         6,942,972      branches:u                #    9.117 M/sec
           707,780      branch-misses:u           #   10.19% of all branches

       0.764757214 seconds time elapsed

       0.233098000 seconds user
       0.529691000 seconds sys

********************************************************************************

* Semaphore benchmark run on koios6 

perf stat taskset 0x01 ./context_switching sem
Using semaphore switch.
Arithmetic mean context-switch roundtrip:	3.377680 microseconds
Sample std. dev. context-switch roundtrip:	1.870308 microseconds
Min. context-switch roundtrip:	3.000000 microseconds
Max. context-switch roundtrip:	311.000000 microseconds

 Performance counter stats for 'taskset 0x01 ./context_switching sem':

            535.64 msec task-clock:u              #    0.995 CPUs utilized
                 0      context-switches:u        #    0.000 K/sec
                 0      cpu-migrations:u          #    0.000 K/sec
               608      page-faults:u             #    0.001 M/sec
        90,624,243      cycles:u                  #    0.169 GHz
        38,652,320      instructions:u            #    0.43  insn per cycle
        10,524,521      branches:u                #   19.649 M/sec
           707,597      branch-misses:u           #    6.72% of all branches

       0.538262969 seconds time elapsed

       0.199745000 seconds user
       0.337075000 seconds sys

********************************************************************************
