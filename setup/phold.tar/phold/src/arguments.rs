use super::print_str;

pub struct Arguments {
    pub nhosts: usize,
    pub weights_filename: String,
    pub cpu_load: usize,
    pub msg_load: usize,
    pub enable_logging: u8,
    pub seed: u64,
    pub use_shadow_addressing: bool,
    pub use_uname_idx_lookup: bool,
}

impl Arguments {
    /// # Safety
    ///
    /// This function should be safe as long as C program args are passed in.
    pub unsafe fn new(argc: i32, argv: *const *const u8) -> Arguments {

        use std::ffi::CStr;

        if argc != 9 {
            print_str("Usage: phold nhosts (weights_filename|uniform|skewed|ring) cpu_load msg_load enable_logging=[0|1] seed use_shadow_addressing=[true|false] use_uname_idx_lookup=[true|false]", true);
            libc::exit(libc::EXIT_FAILURE);
        }

        let nhosts_str: &str;
        let weights_filename: &str;
        let cpu_load_str: &str;
        let msg_load_str: &str;
        let enable_logging_str: &str;
        let seed_str: &str;
        let use_shadow_addressing_str: &str;
        let use_uname_idx_lookup_str: &str;

        nhosts_str = CStr::from_ptr(*argv.add(1)  as *const i8).to_str().unwrap();
        weights_filename = CStr::from_ptr(*argv.add(2)  as *const i8).to_str().unwrap();
        cpu_load_str = CStr::from_ptr(*argv.add(3)  as *const i8).to_str().unwrap();
        msg_load_str = CStr::from_ptr(*argv.add(4)  as *const i8).to_str().unwrap();
        enable_logging_str = CStr::from_ptr(*argv.add(5)  as *const i8).to_str().unwrap();
        seed_str = CStr::from_ptr(*argv.add(6)  as *const i8).to_str().unwrap();
        use_shadow_addressing_str = CStr::from_ptr(*argv.add(7)  as *const i8).to_str().unwrap();
        use_uname_idx_lookup_str = CStr::from_ptr(*argv.add(8)  as *const i8).to_str().unwrap();

        print_str(&("nhosts: ".to_owned() + nhosts_str), true);
        print_str(&("weights_filename: ".to_owned() + weights_filename), true);
        print_str(&("cpu_load: ".to_owned() + cpu_load_str), true);
        print_str(&("msg_load: ".to_owned() + msg_load_str), true);
        print_str(&("enable_logging: ".to_owned() + enable_logging_str), true);
        print_str(&("seed: ".to_owned() + seed_str), true);
        print_str(&("use_shadow_addressing: ".to_owned() + use_shadow_addressing_str), true);
        print_str(&("use_uname_idx_lookup: ".to_owned() + use_uname_idx_lookup_str), true);

        Arguments{nhosts: nhosts_str.parse().unwrap(),
                  weights_filename: weights_filename.to_string(),
                  cpu_load: cpu_load_str.parse().unwrap(),
                  msg_load: msg_load_str.parse().unwrap(),
                  enable_logging: enable_logging_str.parse().unwrap(),
                  seed: seed_str.parse().unwrap(),
                  use_shadow_addressing: use_shadow_addressing_str.parse().unwrap(),
                  use_uname_idx_lookup: use_uname_idx_lookup_str.parse().unwrap()
        }
    }
}
