#![no_main]

fn identify_ip_addr_u32(use_shadow_addressing: bool) -> Option<u32> {
    use std::net::Ipv4Addr;
    use phold::print_str;

    let addrs = nix::ifaddrs::getifaddrs().unwrap();

    for ifaddr in addrs {
        if let Some(nix::sys::socket::SockAddr::Inet(address)) = ifaddr.address {
            let address_str = address.to_str();
            let ip = address_str.split(":").collect::<Vec<&str>>()[0];
            let parsed_addr: Ipv4Addr = ip.parse().unwrap();
            if parsed_addr.is_loopback() {
                continue;
            }

            let octets = parsed_addr.octets();

            if !use_shadow_addressing && (octets[3] == 0 || octets[3] == 255) {
                // invalid address. just quit
                print_str("This host was assigned a bad IP address.", true);
                unsafe { libc::exit(libc::EXIT_SUCCESS); }
            } else {
                let addr_u32 = octets[0] as u32 * (1 << 24) +
                           octets[1] as u32 * (1 << 16) +
                           octets[2] as u32 * (1 << 8) +
                           octets[3] as u32;

                return Some(addr_u32);
            }

        }
    }

    None
}

fn uname_host_idx() -> usize {
    phold::print_str("Using uname() to get host index.", true);

    let uname_info = nix::sys::utsname::uname();

    let v: String = uname_info.nodename().chars().filter(|c| c.is_numeric()).collect();

    let hostn: usize = v.parse().unwrap();

    hostn - 1
}

fn compute_host_index(ipv4_addr_u32: u32, use_shadow_addressing: bool) -> usize {
    let delta = ipv4_addr_u32 - (phold::base_addr_host_order() + 1);

    match use_shadow_addressing {
        true => delta as usize,
        false => {
            let network_num = delta / 256;
            (delta - (2 * network_num)) as usize
        }
    }
}

#[no_mangle]
pub extern "C" fn main(argc: i32, argv: *mut *mut u8) -> i32 {

    use std::cell::RefCell;
    use std::rc::Rc;
    use phold::weight_interpolator::WeightInterpolator;

    // PDF of e^-3x, 0 <= x <= 1
    let exp_weights =
        [1.0, 0.860708, 0.740818, 0.637628, 0.548812, 0.472367, 0.40657, 0.349938, 0.301194,
        0.25924, 0.22313, 0.19205, 0.165299, 0.142274, 0.122456, 0.105399, 0.090718, 0.0780817,
        0.0672055, 0.0578443, 0.0497871];

    let args = unsafe { phold::arguments::Arguments::new(argc, argv as *const *const u8) };

    let my_host_idx = match args.use_uname_idx_lookup {
        true => uname_host_idx(),
        false => {
            let ipv4_addr_u32 = identify_ip_addr_u32(args.use_shadow_addressing).unwrap();
            compute_host_index(ipv4_addr_u32, args.use_shadow_addressing)
        }
    };

    unsafe { phold::RNG.initialize_and_seed(args.seed ^ my_host_idx as u64); }

    let sample_idx_fn: Box<dyn Fn() -> usize>;

    match &args.weights_filename[..] {

        "uniform" => {
            let ntmp = args.nhosts; // Used to move into closure
            sample_idx_fn = Box::new(move || {
                assert!(ntmp <= std::u32::MAX as usize);
                phold::adjust_sampled_idx(phold::uniform_random_u32(0, (ntmp - 2) as u32) as usize,
                                          my_host_idx)
            });
        },

        "skewed" => {
            let weight_interp = Rc::new(RefCell::new(WeightInterpolator::new(&exp_weights, args.nhosts - 1)));

            sample_idx_fn = Box::new(move || {
                let weight_interp_copy = Rc::clone(&weight_interp);
                let idx = WeightInterpolator::sample_host_idx(&mut weight_interp_copy.borrow_mut());
                phold::adjust_sampled_idx(idx, my_host_idx)
            });
        },

        "ring" => {
            let idxtmp = my_host_idx;
            let ntmp = args.nhosts; // Used to move into closure
            sample_idx_fn = Box::new(move || {
                (idxtmp + 1) % ntmp
            });
        },

        _ => {
            let weight_interp = Rc::new(RefCell::new(WeightInterpolator::from_file(&args.weights_filename, args.nhosts - 1)));

            sample_idx_fn = Box::new(move || {
                let weight_interp_copy = Rc::clone(&weight_interp);
                let idx = WeightInterpolator::sample_host_idx(&mut weight_interp_copy.borrow_mut());
                phold::adjust_sampled_idx(idx, my_host_idx)
            });
        }

    }

    let mut server = phold::network_server::NetworkServer::new(
        sample_idx_fn,
        args.cpu_load,
        args.msg_load,
        args.use_shadow_addressing,
        my_host_idx
        );

    if args.enable_logging == 1 {
        unsafe { server.create_log_thread(); }
    }

    server.send_initial_msgs();
    server.work_loop();

    0
}
