use super::uniform_random;
use std::os::unix::io::RawFd;
use splines::{Interpolation, Key, Spline};

fn query_file_size(fd: RawFd) -> i64 {
    use nix::sys::stat::fstat;

    let stats = fstat(fd).unwrap();
    stats.st_size
}

fn read_weights_file(filename: &str) -> Vec<f64> {

    use nix::fcntl::*;
    use nix::sys::stat::*;
    use nix::unistd::read;

    let mut weights: Vec<f64> = vec![];

    let fd = open(filename, OFlag::O_RDONLY, Mode::S_IXUSR).unwrap();
    let file_nbytes = query_file_size(fd) as usize;
    let mut buf: Vec<u8> = vec![0; file_nbytes];
    let read_nbytes = read(fd, buf.as_mut_slice()).unwrap();

    if file_nbytes != read_nbytes {
        panic!("Could not read entire file contents!");
    }

    let decoded_contents = String::from_utf8(buf).unwrap();

    for line in decoded_contents.split('\n') {
        if let Ok(value) = line.parse::<f64>() {
            weights.push(value);
        }
    }

    weights.drain(..).filter(|x| x > &0.0).collect()
}

pub struct WeightInterpolator {
    spline: Spline<f64, f64>,
    nhosts: usize,
}

impl WeightInterpolator {
    pub fn new(weights: &[f64], nhosts: usize) -> WeightInterpolator {

        assert!(weights.len() >= 2);

        let total_weight: f64 = weights.iter().sum();

        let mut norm_cumul_weights = vec![0.0];
        norm_cumul_weights.reserve(weights.len() + 2);

        let mut acc: f64 = 0.0;
        for weight in weights {
            acc += weight / total_weight;
            norm_cumul_weights.push(acc)
        }

        let linspace = WeightInterpolator::normal_linspace(norm_cumul_weights.len());

        let spline = WeightInterpolator::make_spline(norm_cumul_weights.as_slice(), linspace.as_slice()).unwrap();

        WeightInterpolator{spline, nhosts}
    }

    pub fn from_file(filename: &str, nhosts: usize) -> WeightInterpolator {
        let weights = read_weights_file(&filename);
        WeightInterpolator::new(&weights, nhosts)
    }

    pub fn sample_host_idx(&self) -> usize {
        let r = uniform_random();
        let x = self.spline.clamped_sample(r).unwrap();
        ((x.clamp(0.0, 1.0 - f64::EPSILON) * ((self.nhosts)as f64)) as usize).clamp(0, self.nhosts - 1)
    }

    fn make_spline(xs: &[f64], ys: &[f64]) -> Option<splines::Spline<f64, f64>> {
        let n = xs.len();

        if ys.len() != n || n < 2 {
            return None;
        }

        let mut vec = vec![];

        let key_interp = Interpolation::Linear;

        for idx in 0..n {
            vec.push(Key::new(xs[idx], ys[idx], key_interp));
        }

        let spline = Spline::from_vec(vec);
        Some(spline)
    }

    fn normal_linspace(n: usize) -> Vec<f64> {
        let mut points = vec![];
        points.reserve(n);

        if n < 2 {
            return vec![];
        }

        let div = (n - 1) as f64;

        for idx in 0..(n-1) {
            points.push((1.0 / div) * (idx as f64));
        }

        points.push(1.0);

        points
    }

}
