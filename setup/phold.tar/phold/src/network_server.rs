use super::print_str;

use libc::c_void;

use std::ptr;
use std::os::raw::c_int;
use std::os::unix::io::RawFd;
use std::sync::atomic::{AtomicUsize, Ordering};

const PORT_HOST_ORDER: u16 = 3333;

pub struct NetworkServer {
    send_fd: RawFd,
    #[allow(dead_code)]
    recv_fd: RawFd,
    poll_fds: Vec::<nix::poll::PollFd>,
    recv_buf: Vec::<u8>,
    send_buf: Vec::<u8>,
    sample_idx_fn: Box<dyn Fn() -> usize>,
    cipher: aes::Aes128,
    cpu_load: usize,
    msg_load: usize,
    logger_thread: libc::pthread_t,
    npackets_sent: AtomicUsize,
    npackets_recv: AtomicUsize,
    magic: u64,
    child_stack: Vec::<u8>,
    use_shadow_addressing: bool,
}

impl NetworkServer {

    extern "C" fn log_wrapper(userdata: *mut c_void) -> i32 {
        NetworkServer::log(userdata);
        0
    }

    #[allow(unreachable_code)]
    extern "C" fn log(userdata: *mut c_void) -> *mut c_void {
        // Spooky
        let ns: &NetworkServer = unsafe { (userdata as *mut NetworkServer).as_ref().unwrap() };

        loop {

            nix::unistd::sleep(1);

            if ns.magic != NetworkServer::magic_const() {
                panic!("NetworkServer magic value mismatch.");
            }

            let sent = ns.npackets_sent.load(Ordering::Relaxed);
            let recv = ns.npackets_recv.load(Ordering::Relaxed);

            print_str(&("Num packets sent: ".to_owned() + &sent.to_string()), true);
            print_str(&("Num packets recv: ".to_owned() + &recv.to_string()), true);
        }

        ptr::null_mut()
    }

    /// # Safety
    ///
    /// Explodes if pthread_create explodes.
    pub unsafe fn create_log_thread(&mut self) {

        let self_ptr = self as *mut _ as *mut c_void;

        let pthread_create_rc = libc::pthread_create(&mut self.logger_thread,
                             ptr::null(),
                             NetworkServer::log,
                             self_ptr);

        if pthread_create_rc != 0 {
            panic!("Error on pthread_create!");
        }
    }

    /// # Safety
    ///
    /// Explodes if clone explodes.
    pub unsafe fn create_log_thread_clone(&mut self) {

        let self_ptr = self as *mut _ as *mut c_void;
        self.child_stack.resize(32768, 0);

        let flags = libc::CLONE_VM | libc::CLONE_FS | libc::CLONE_FILES | libc::CLONE_SIGHAND | libc::CLONE_THREAD | libc::CLONE_SYSVSEM;

        let clone_rc = libc::clone(NetworkServer::log_wrapper,
                                   self.child_stack.as_mut_ptr() as *mut _,
                                   flags,
                                   self_ptr);

        if clone_rc < 0 {
            print_str("Couldn't clone!", true);
            panic!("Error on clone");
        }

    }

    pub fn new(sample_idx_fn: Box<dyn Fn() -> usize>, cpu_load: usize, msg_load: usize, use_shadow_addressing: bool, host_idx: usize) -> NetworkServer {
        use aes::cipher::generic_array::GenericArray;
        use aes::Aes128;
        use aes::NewBlockCipher;

        let send_fd = NetworkServer::create_send_fd();
        let recv_fd = NetworkServer::create_recv_fd(host_idx, use_shadow_addressing);

        let mut recv_buf = Vec::<u8>::new();
        recv_buf.resize(NetworkServer::recv_buf_nbytes(), 0);

        let mut send_buf = Vec::<u8>::new();
        send_buf.resize(NetworkServer::send_buf_nbytes(), 0);

        let mut poll_flags = nix::poll::PollFlags::empty();
        poll_flags.set(nix::poll::PollFlags::POLLIN, true);

        let poll_fds = vec![ nix::poll::PollFd::new(recv_fd, poll_flags) ];

        let key = GenericArray::from_slice(&[0u8; 16]);
        let cipher = Aes128::new(&key);

        NetworkServer{send_fd, recv_fd, poll_fds,
                      recv_buf, send_buf, sample_idx_fn, 
                      cipher, cpu_load, msg_load,
                      logger_thread: 0,
                      npackets_sent: AtomicUsize::new(0),
                      npackets_recv: AtomicUsize::new(0),
                      magic: NetworkServer::magic_const(),
                      child_stack: Vec::<u8>::new(),
                      use_shadow_addressing}

    }

    #[inline]
    fn magic_const() -> u64 { 0xCAFEBABE }

    #[inline]
    fn recv_buf_nbytes() -> usize { 2048 }

    #[inline]
    fn send_buf_nbytes() -> usize { 1024 }

    // No nix getaddrinfo?
    fn create_recv_fd(host_idx: usize, use_shadow_addressing: bool) -> RawFd {
        let sock_fd : c_int;

        let sockaddr: libc::sockaddr_in = NetworkServer::lookup_host(use_shadow_addressing, host_idx);
        let addrlen = std::mem::size_of::<libc::sockaddr_in>() as u32;

        unsafe {
            sock_fd = libc::socket(libc::AF_INET, libc::SOCK_DGRAM, 0);

            if sock_fd < 1 {
                panic!("socket() failed unexpectedly.");
            }

            let bind_rc = libc::bind(sock_fd, &sockaddr as *const _ as *const libc::sockaddr, addrlen);

            if bind_rc != 0 {
                panic!("bind() failed unexpectedly.");
            }

        }

        NetworkServer::set_fd_nonblocking(sock_fd);

        sock_fd
    }

    fn create_send_fd() -> RawFd {
        use nix::sys::socket::*;

        let domain = AddressFamily::Inet;
        let socktype = SockType::Datagram;
        let mut flags = SockFlag::empty();
        flags.insert(SockFlag::SOCK_NONBLOCK);

        let sock_fd = socket(domain, socktype, flags, None).unwrap();

        NetworkServer::set_fd_nonblocking(sock_fd);

        sock_fd
    }

    fn lookup_host(use_shadow_addressing: bool, host_idx: usize) -> libc::sockaddr_in {

        let s_addr: u32 = match use_shadow_addressing {
            true => {
                ((super::base_addr_host_order() as usize) + 1 + host_idx) as u32
            },
            false => {
                let naddrs_per_network = 254; // Assuming x.y.z.0 and x.y.z.255 are not valid host addrs.
                let network_num = host_idx / naddrs_per_network;
                let host_offset = host_idx % naddrs_per_network;
                ((super::base_addr_host_order() as usize) + (network_num * 256) + host_offset + 1) as u32
            },
        };

        let addr: libc::sockaddr_in = libc::sockaddr_in {
            sin_family: libc::AF_INET as u16,
            sin_port: PORT_HOST_ORDER.to_be(), // be = big-endian
            sin_addr: libc::in_addr { s_addr: s_addr.to_be() },
            sin_zero: [0; 8],
        };

        addr
    }

    fn set_fd_nonblocking(fd: RawFd) {
        let old_flags = nix::fcntl::fcntl(fd, nix::fcntl::F_GETFL).unwrap();
        let mut new_flags = nix::fcntl::OFlag::from_bits(old_flags).unwrap();
        new_flags.set(nix::fcntl::OFlag::O_NONBLOCK, true);
        nix::fcntl::fcntl(fd, nix::fcntl::F_SETFL(new_flags)).unwrap();
    }

    pub fn send_initial_msgs(&mut self) {
        self.send_n_msgs(self.msg_load);
    }

    pub fn send_msg_to_random(&mut self) -> bool {

        use std::mem;

        let addr = NetworkServer::lookup_host(self.use_shadow_addressing, (self.sample_idx_fn)());

        let addrlen = mem::size_of::<libc::sockaddr_in>() as u32;

        let sendto_rc = unsafe { libc::sendto(self.send_fd,
                              self.send_buf.as_slice() as *const _ as *const std::ffi::c_void,
                              self.send_buf.len(), 0, (&addr) as *const _ as *const libc::sockaddr, addrlen) };

        if sendto_rc != (NetworkServer::send_buf_nbytes() as isize) {
            print_str("Unexpected error on sendto", true);
            false
        } else {
            true
        }
    }

    pub fn send_n_msgs(&mut self, nmsgs: usize) {
        for _ in 0..nmsgs {
            if self.send_msg_to_random() {
                self.npackets_sent.fetch_add(1, Ordering::Relaxed);
            }
        }
    }

    // Returns success or failure.
    pub fn recv_msg(&mut self, sock_fd: RawFd) -> bool {
        let retv = nix::sys::socket::recvfrom(sock_fd, self.recv_buf.as_mut_slice());

        if retv.is_err() {
            print_str("Unexpected error on recvfrom", true);
            return false;
        }

        true
    }

    pub fn wait_for_msg(&mut self) {
        let nevents = nix::poll::poll(&mut self.poll_fds[..], -1).unwrap();
        assert!(nevents == 1);
        self.recv_msg(self.recv_fd);
        self.npackets_recv.fetch_add(1, Ordering::Relaxed);
    }

    fn cpu_load(&mut self, nmsgs: usize) {
        use aes::BlockCipher;
        use aes::cipher::generic_array::GenericArray;

        let mut buf = [0u8; 16];

        let load = nmsgs * (NetworkServer::send_buf_nbytes() / 16) * self.cpu_load;

        for _ in 0..load {
            self.cipher.encrypt_block(GenericArray::from_mut_slice(&mut buf));
            self.cipher.decrypt_block(GenericArray::from_mut_slice(&mut buf));
        }
    }

    pub fn work_loop(&mut self) {
        loop {
            self.wait_for_msg();
            self.cpu_load(1);
            self.send_n_msgs(1);
        }
    }

}
