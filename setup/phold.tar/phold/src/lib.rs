pub mod arguments;
pub mod network_server;
pub mod weight_interpolator;

use rand_xoshiro::Xoshiro256StarStar;
use rand_xoshiro::rand_core::{SeedableRng, RngCore};

pub struct Rng {
    rng: Option<Xoshiro256StarStar>,
    lock: libc::pthread_mutex_t,
}

impl Rng {

    pub fn initialize_and_seed(&mut self, seed: u64) {
        self.rng = Some(Xoshiro256StarStar::seed_from_u64(seed));
        
        unsafe {
            libc::pthread_mutex_init(&mut self.lock, std::ptr::null());
        }
    }

    pub fn sample_u64(&mut self) -> u64 {

        unsafe { libc::pthread_mutex_lock(&mut self.lock); }

        let retv = match self.rng {
            Some(ref mut x) => { x.next_u64() },
            None => { 0 }
        };

        unsafe { libc::pthread_mutex_unlock(&mut self.lock); }

        retv
    }
}

pub static mut RNG: Rng = Rng {
    rng: None,
    lock: libc::PTHREAD_MUTEX_INITIALIZER,
};


pub fn print_str(buf: &str, newline: bool) {
    use nix::unistd::{write};

    let nbytes = write(libc::STDOUT_FILENO, buf.as_bytes()).unwrap();

    if nbytes != buf.len() {
        panic!("Couldn't write to stdout!");
    }

    if newline && write(libc::STDOUT_FILENO, "\n".as_bytes()).unwrap() != 1 {
        panic!("Couldn't write to stdout!");
    }
}

/*
 * Generate a value uniformly between 0 and 1. Naive implementation.
 */
pub fn uniform_random() -> f64 {
    let rand_value = unsafe { RNG.sample_u64() };
    (rand_value as f64) / (u64::MAX as f64)
}

/*
 * Viega & Messier
 * Output is random int in [a, b].
 */
pub fn uniform_random_u32(a: u32, b: u32) -> u32 {
    assert!(b >= a);
    let range = b - a + 1;

    let mut r: u32;
    let max_val = u32::MAX;

    loop {
        r = unsafe { (RNG.sample_u64() % (u32::MAX as u64)) as u32 };
        if r <= max_val - (max_val % range) { break; }
    }

    a + ((r as u32) % range)
}

pub fn base_addr_host_order() -> u32 {
    184549376
}

pub fn adjust_sampled_idx(sampled_idx: usize, host_idx: usize) -> usize {
    if sampled_idx < host_idx {
        sampled_idx
    } else {
        sampled_idx + 1
    }
}
