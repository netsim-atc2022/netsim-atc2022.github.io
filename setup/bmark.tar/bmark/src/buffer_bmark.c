#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "aux.h"

static const size_t _BLOCK_NBYTES_DEFAULT = 1 << 12;
static size_t _block_nbytes_chosen = _BLOCK_NBYTES_DEFAULT;

enum { WARMUP_ITERATIONS = 1000, NSAMPLES = 10000 };

static void _write_and_read_pipes(int write_fd, int read_fd,
                                  const void* write_buf, void* read_buf,
                                  size_t buf_nbytes) {
  assert(write_fd > 0 && read_fd > 0);
  assert(write_buf && read_buf);
  assert(buf_nbytes > 0);

  ssize_t nbytes_written = write(write_fd, write_buf, buf_nbytes);
  ssize_t nbytes_read = read(read_fd, read_buf, (size_t)nbytes_written);

  if (nbytes_written != buf_nbytes || nbytes_read != buf_nbytes) {
    print_nullterm_string(STDERR_FILENO, "read() or write() failed.");
    abort();
  }
}

static void _read_and_write_std(void* args) {
  int* typed_args = (int*)args;

  int write_fd = typed_args[1];
  int read_fd = typed_args[0];

  static char *write_buf = NULL, *read_buf = NULL;

  if (!write_buf) {
    write_buf = calloc(1, _block_nbytes_chosen);
  }
  if (!read_buf) {
    read_buf = calloc(1, _block_nbytes_chosen);
  }

  _write_and_read_pipes(write_fd, read_fd, write_buf, read_buf, _block_nbytes_chosen);
}

int buffer_bmark_main(int argc, char** argv) {
  const char* usage =
      "Usage: %s 0|1 nbytes\nPass 1 if running inside Phantom, otherwise 0.\nnbytes is the num bytes for each write/read sequence.\n";

  if (argc < 3) {
    fprintf(stderr, usage, argv[0]);
    exit(EXIT_FAILURE);
  }

  if (strcmp(argv[1], "0") == 0) {
  } else if (strcmp(argv[1], "1") == 0) {
    set_use_shadow_syscall_defn();
  } else {
    fprintf(stderr, usage, argv[0]);
    exit(EXIT_FAILURE);
  }

  long nbytes = 0;
  int nparsed = sscanf(argv[2], "%ld", &nbytes);

  if (nparsed != 1 || nbytes <= 0) {
      fprintf(stderr, usage, argv[0]);
      exit(EXIT_FAILURE);
  }
  _block_nbytes_chosen = (size_t) nbytes;

  print_nullterm_string(STDOUT_FILENO, "# Running buffer benchmark using nbytes = ");
  print_long(STDOUT_FILENO, _block_nbytes_chosen);

  double* times_ms = calloc(NSAMPLES, sizeof(double));
  assert(times_ms);

  time_fn(WARMUP_ITERATIONS, NULL, NULL, NULL);
  time_fn(NSAMPLES, NULL, NULL, times_ms);

  for (size_t idx = 0; idx < NSAMPLES; ++idx) {
    print_nullterm_string(STDOUT_FILENO,
                          "Time spent in no-op function call (ms)\t");
    print_double(STDOUT_FILENO, times_ms[idx]);
  }

  int pipe_fd[2] = {-1, -1};

  int rc = pipe2(pipe_fd, 0);
  if (rc) {
    perror("pipe2");
    exit(EXIT_FAILURE);
  }

  time_fn(WARMUP_ITERATIONS, _read_and_write_std, pipe_fd, NULL);
  time_fn(NSAMPLES, _read_and_write_std, pipe_fd, times_ms);

  for (size_t idx = 0; idx < NSAMPLES; ++idx) {
      print_nullterm_string(STDOUT_FILENO, "Time spent in write/read function calls (ms)\t");
      print_double(STDOUT_FILENO, times_ms[idx]);
  }

  free(times_ms);

  return 0;
}
