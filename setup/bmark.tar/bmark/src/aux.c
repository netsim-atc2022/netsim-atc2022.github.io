#include "aux.h"
#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include <dlfcn.h>
#include <sys/syscall.h>

static bool _use_shadow_syscall_defn = false;

typedef long (*Syscall_t)(long, ...);
typedef bool (*InterposeSwitch_t)();

InterposeSwitch_t _disable_interpose = NULL;
InterposeSwitch_t _enable_interpose = NULL;

static int (*_shadow_set_ptrace_allow_native_syscalls)(bool) = NULL;

// fp should point to a function pointer
static void _find_fn(const char *fname, void *fp) {
  void *retv = dlsym(RTLD_DEFAULT, fname);
  if (!retv) {
    fprintf(stderr, "Error resolving symbol %s. Aborting.\n", fname);
    abort();
  } else {
    *(void **)(fp) = retv;
  }
}

static Syscall_t _syscall_impl = NULL;

bool use_shadow_syscall_defn() {
    return _use_shadow_syscall_defn;
}

void set_use_shadow_syscall_defn() {
    _use_shadow_syscall_defn = true;
    _find_fn("shadow_real_raw_syscall", &_syscall_impl);
    _find_fn("shim_disableInterposition", &_disable_interpose);
    _find_fn("shim_enableInterposition", &_enable_interpose);
    _find_fn("shadow_set_ptrace_allow_native_syscalls", &_shadow_set_ptrace_allow_native_syscalls);
}

int get_real_time(struct timespec* tp) {
  if (use_shadow_syscall_defn()) {

    assert(_syscall_impl && _disable_interpose && _enable_interpose);

    long arg0 = SYS_clock_gettime;
    long arg1 = CLOCK_MONOTONIC;
    long arg2 = (long)tp;

    _disable_interpose();
    _shadow_set_ptrace_allow_native_syscalls(true);
    int retv = (*_syscall_impl)(arg0, arg1, arg2);
    _shadow_set_ptrace_allow_native_syscalls(false);
    _enable_interpose();
    return retv;

  } else {
    return asm_gettime(tp);
  }
}
