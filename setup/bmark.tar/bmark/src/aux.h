#ifndef AUX_H_
#define AUX_H_
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/*
 * Copy+paste from OpenBSD's implementation in <sys/time.h>.
 */
#define timespecsub(tsp, usp, vsp)                    \
  do {                                                \
    (vsp)->tv_sec = (tsp)->tv_sec - (usp)->tv_sec;    \
    (vsp)->tv_nsec = (tsp)->tv_nsec - (usp)->tv_nsec; \
    if ((vsp)->tv_nsec < 0) {                         \
      (vsp)->tv_sec--;                                \
      (vsp)->tv_nsec += 1000000000L;                  \
    }                                                 \
  } while (0)

// The "do ... while (0)" is magic to make this multi-line macro work.
// <https://stackoverflow.com/questions/257418/do-while-0-what-is-it-good-for>

typedef void (*StandardFn_t)(void *);

bool use_shadow_syscall_defn();
void set_use_shadow_syscall_defn();

int asm_gettime(struct timespec *t);

int get_real_time(struct timespec *tp);

static inline void print_double(int file_no, double x) {
  enum { BUF_NBYTES = 64 };
  char buf[BUF_NBYTES] = {0};
  snprintf(buf, BUF_NBYTES, "%.9f\n", x);
  write(file_no, buf, strlen(buf));
}

static inline void print_long(int file_no, long x) {
  enum { BUF_NBYTES = 64 };
  char buf[BUF_NBYTES] = {0};
  snprintf(buf, BUF_NBYTES, "%ld\n", x);
  write(file_no, buf, strlen(buf));
}

static inline void print_nullterm_string(int file_no, const char *s) {
  write(file_no, s, strlen(s));
}

static inline double timespec_to_seconds(const struct timespec *t) {
  return (double)t->tv_sec + (double)t->tv_nsec * 1E-9;
}

static inline void time_fn(size_t nsamples, StandardFn_t fn, void *args,
                           double *times_ms) {
  struct timespec t0 = {0}, t1 = {0}, delta_t = {0};

  for (size_t idx = 0; idx < nsamples; ++idx) {
    get_real_time(&t0);
    if (fn) {
      fn(args);
    }
    get_real_time(&t1);
    timespecsub(&t1, &t0, &delta_t);

    if (times_ms) {
      times_ms[idx] = timespec_to_seconds(&delta_t) * 1000.;
    }
  }
}

#endif  // AUX_H_
