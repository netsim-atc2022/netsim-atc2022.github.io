#!/usr/bin/env python3

import argparse
import datetime
import json
import os
import re

import numpy as np
import pandas as pd
import scipy.stats

Z_ALPHA = 1.96 # 95% confidence interval

def str_to_bool(value):
    if value == "True":
        return True
    elif value == "False":
        return False
    else:
        assert False

def fix_realtime_parameters(parameters):

    realtime = False
    
    if "realtime_classic" in parameters:
        realtime = realtime or parameters["realtime_classic"]

    if "realtime" in parameters:
        realtime = realtime or parameters["realtime"]

    parameters["realtime"] = realtime
    del parameters["realtime_classic"]
    return parameters

def compute_stats(values):

    mean = np.mean(values)
    sample_stddev = np.std(values, ddof=1)
    n = float(len(values))

    lb = mean - Z_ALPHA * (sample_stddev / np.sqrt(n))
    ub = mean + Z_ALPHA * (sample_stddev / np.sqrt(n))

    return {
        "mean" : mean,
        "mean_lb" : lb,
        "mean_ub" : ub,
        "stddev" : sample_stddev,
        "min" : min(values),
        "geometric_mean" : scipy.stats.mstats.gmean(values),
        "values" : values }

def extract_experiment(full_path):

    match = re.match(".*___(.*?)/.*", full_path)
    if match is not None:
        experiment_string = match.group(1)

        experiment_fields = experiment_string.split("__")
        benchmark = experiment_fields[0]
        simulator = experiment_fields[1]
        params = experiment_fields[2:]

        return {"benchmark" : benchmark,
                "simulator" : simulator,
                "parameters" : " ".join(params)}

def read_stdout_file(full_path):

    values = []

    with open(full_path, "r") as f:
        for line in f:
            values.append(float(line))

    return values

def main(args):

    records = []

    for dirname in args.dirs:

        for root, dirs, files in os.walk(dirname):
            for filename in files:
                if re.match(".*stdout.*", filename) is not None:
                    full_path = os.path.join(root, filename)
                    experiment = extract_experiment(full_path)
                    values = read_stdout_file(full_path)
                    stats = compute_stats(values)
                    records.append({**experiment, **stats})

    df = pd.DataFrame(records)

    for benchmark in set(df["benchmark"]):
        benchmark_df = df[df["benchmark"] == benchmark]
        benchmark_df = benchmark_df.sort_values("mean")
        min_gmean = min(benchmark_df["geometric_mean"])
        benchmark_df["slowdown"] = benchmark_df["geometric_mean"] / min_gmean

        records = benchmark_df.to_dict(orient="records")

        for record in records:
            record["parameters"] = record["parameters"].split(" ")

            parameters = {}
            for item in record["parameters"]:
                key, value = item.split("-")
                value = str_to_bool(value)
                parameters[key] = value

            record["parameters"] = fix_realtime_parameters(parameters)

        if args.json:
            timestamp = str(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
            with open("{}_{}.json".format(benchmark, timestamp), "w") as f:
                json.dump(records, f)
        else:
            del benchmark_df["values"]
            print(benchmark_df.to_string())


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("dirs", nargs='*')
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()

if __name__ == "__main__":
    main(parse_args())
