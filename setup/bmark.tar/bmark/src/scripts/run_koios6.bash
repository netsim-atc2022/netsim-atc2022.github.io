#!/usr/bin/env bash

set -eoux pipefail

SHADOW_EXE=/scratch/rwails/shadow-pre/install/bin/shadow

python3 ./run_bmarks.py ./template_config_python.xml ../benchmark classic \
    -b classic -e $SHADOW_EXE

exit

PHANTOM_EXE=/scratch/rwails/shadow/build/src/main/shadow

python3 ./run_bmarks.py ./template_config_python.xml ../benchmark phantom \
    -b phantom -e $PHANTOM_EXE
