n.b. Make sure that the soft and hard realtime limits are raised for your
account before running these benchmarks or the realtime experiments will fail.
See `$ ulimit -Hr`, `$ ulimit -Sr`, and /etc/security/limits.conf


To collect Classic samples
********************************************************************************

1. Checkout and build the master branch. Install shadow into the path.

2. Run `$ ./run_bmarks.py ./template_config_python.xml ../benchmark classic -b classic`

To collect Phantom samples
********************************************************************************

1. Checkout and build RWails/shadow-phantom-pub on the `benchmark` branch. This
branch contains a modificaiton to `clock_gettime` that allows the plugin to
fetch the real system clock using clockid 66666.  The branch also increases
Phantom's IPC buffer sizes to support the buffer size used in the BUFFER
microbenchmark.

Install shadow into the path.

Ref: <https://github.com/RWails/shadow-phantom-pub/tree/benchmark>.

2. Run `$ ./run_bmarks.py ./template_config_python.xml ../benchmark phantom -b phantom`

To process the results
********************************************************************************

Run `$ ./collect_results.py classic phantom`
