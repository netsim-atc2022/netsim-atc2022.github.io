#!/usr/bin/env python3
import argparse
from itertools import chain, combinations
import os
import subprocess
import sys
import tempfile

def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))

BENCHMARKS = ["BUFFER", "SYSCALL_NONBLOCKING", "SYSCALL_BLOCKING"]

BENCHMARK_COMMAND_PATTERNS = {
        "BUFFER" : "BUFFER {}",
        "SYSCALL_NONBLOCKING" : "SYSCALL 0 {}",
        "SYSCALL_BLOCKING" : "SYSCALL 1 {}"
}

CLASSIC_MODIFIERS = ["pinned", "single_core", "realtime_classic"]
PHANTOM_MODIFIERS = ["pinned", "single_core", "no_spin", "realtime"]
ALL_MODIFIERS = list(sorted(set(CLASSIC_MODIFIERS + PHANTOM_MODIFIERS)))
SHADOW_COMMAND_STEM = " -l error {}"

base_data_directory = "."

def get_data_directory(benchmark, simulator, active_modifiers):

    os.makedirs(base_data_directory, exist_ok=True)

    data_directory = os.path.join(base_data_directory,
                                  "___" + benchmark + "__" + simulator)

    for modifier in ALL_MODIFIERS:

        data_directory += "__{}-{}".format(modifier, modifier in
                                           active_modifiers)


    return data_directory

def modify_command(command, modifier):

    if modifier == "pinned":
        return command + " -z"
    elif modifier == "single_core":
        return "taskset -c 0 " + command
    elif modifier == "realtime_classic":
        return "chrt -f 1 " + command
    elif modifier == "no_spin":
        return command + " --preload-spin-max=0"
    elif modifier == "realtime":
        return command + " --set-sched-fifo"
    else:
        assert(False)

def run_classic(template_config, plugin_path):

    for benchmark in BENCHMARKS:
        sim = "classic"
        for modifiers in powerset(CLASSIC_MODIFIERS):
            command = SHADOW_COMMAND_STEM

            for modifier in modifiers:
                command = modify_command(command, modifier)

            command += " -d {}".format(get_data_directory(benchmark, sim,
                                                          modifiers))

            print("Running {}".format(command))

            benchmark_args = BENCHMARK_COMMAND_PATTERNS[benchmark].format("0")

            run_shadow(command, template_config, benchmark_args,
                       plugin_path)

def run_phantom(template_config, plugin_path):

    for interpose in ["hybrid", "preload", "ptrace"]:
        for benchmark in BENCHMARKS:
            sim = "phantom-{}".format(interpose)
            for modifiers in powerset(PHANTOM_MODIFIERS):
                command = SHADOW_COMMAND_STEM + " -n {}".format(interpose)

                for modifier in modifiers:
                    command = modify_command(command, modifier)

                command += " -d {}".format(get_data_directory(benchmark, sim,
                                                              modifiers))

                command += " --disable-shim-syscall-handler"

                benchmark_args = BENCHMARK_COMMAND_PATTERNS[benchmark].format("1")

                print(benchmark_args)

                run_shadow(command, template_config, benchmark_args,
                           plugin_path)

def main(args):

    global SHADOW_COMMAND_STEM
    SHADOW_COMMAND_STEM = args.exe + SHADOW_COMMAND_STEM

    global base_data_directory
    base_data_directory = args.base_data_directory

    with open(args.template_config_filename, "r") as f:
        template_config = f.read()

    if args.simulator == "phantom":
        run_phantom(template_config, args.plugin_path)
    elif args.simulator == "classic":
        run_classic(template_config, args.plugin_path)
    else:
        assert(False)

def run_shadow(command_format_str, template_config, plugin_args, plugin_path):

    with tempfile.NamedTemporaryFile(buffering=0, dir='.', delete=True) as f:
        f.write(template_config.format(plugin_args, plugin_path).encode())
        config_filename = f.name
        command = command_format_str.format(config_filename).split(" ")
        rv = subprocess.run(command)
        if rv.returncode != 0:
            sys.exit("Experiment failed! Exiting.")

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("template_config_filename")
    parser.add_argument("plugin_path")
    parser.add_argument("simulator", help="classic|phantom")
    parser.add_argument("-b", "--base_data_directory", default=".")
    parser.add_argument("-e", "--exe", default="shadow")
    return parser.parse_args()

if __name__ == "__main__":
    main(parse_args())
