#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif // _POSIX_C_SOURCE

#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <sys/syscall.h>

#include "aux.h"

enum {
    WARMUP_ITERATIONS = 1000,
    NSAMPLES = 10000
};

static void _nanosleep_std(void *args) {
  struct timespec *typed_args = args;

  const struct timespec sleep_time = typed_args[0];
  struct timespec retval = typed_args[1];

  //nanosleep(&sleep_time, &retval);
  // nanosleep -> libc calls clock_nanosleep using 0 in the first two args
  // We just call it directly to give a fair comparison between when we
  // have preload enabled and when we dont.
  clock_nanosleep(0, 0, &sleep_time, &retval);
}

int syscall_bmark_main(int argc, char** argv) {

    const char* usage =
        "Usage: %s n_nanosecs 0|1\nn_nanoseconds >= 0\nPass 1 if running inside Phantom, otherwise 0.\n";

    if (argc < 3) {
        fprintf(stderr, usage, argv[0]);
        exit(EXIT_FAILURE);
    }

    long ns = 0;
    int nparsed = sscanf(argv[1], "%ld", &ns);

    if (nparsed != 1 || ns < 0) {
        fprintf(stderr, usage, argv[0]);
        exit(EXIT_FAILURE);
    }

    if (strcmp(argv[2], "0") == 0) {
    } else if (strcmp(argv[2], "1") == 0) {
        set_use_shadow_syscall_defn();
    } else {
        fprintf(stderr, usage, argv[0]);
        exit(EXIT_FAILURE);
    }

    print_nullterm_string(STDERR_FILENO, "Running syscall benchmark.\n");

    double* times_ms = calloc(NSAMPLES, sizeof(double));
    assert(times_ms);

    time_fn(WARMUP_ITERATIONS, NULL, NULL, NULL);
    time_fn(NSAMPLES, NULL, NULL, times_ms);

    for (size_t idx = 0; idx < NSAMPLES; ++idx) {
        print_nullterm_string(STDOUT_FILENO, "Time spent in no-op function call (ms)\t");
        print_double(STDOUT_FILENO, times_ms[idx]);
    }

    const struct timespec sleep_time = {0, ns};
    struct timespec retval = {0, 0};
    struct timespec args[] = {sleep_time, retval};

    time_fn(WARMUP_ITERATIONS, _nanosleep_std, args, NULL);
    time_fn(NSAMPLES, _nanosleep_std, args, times_ms);

    for (size_t idx = 0; idx < NSAMPLES; ++idx) {
        print_nullterm_string(STDOUT_FILENO, "Time spent in nanosleep function call (ms)\t");
        print_double(STDOUT_FILENO, times_ms[idx]);
    }

    free(times_ms);
    return 0;
}
